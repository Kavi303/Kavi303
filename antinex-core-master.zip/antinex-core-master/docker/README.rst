AntiNex Core Docker
-------------------

Start the container with Jupyter and JupyterLab with:

::

    cd docker
    ./start-stack.sh

Open Jupyter Notebook with Django Deep Neural Network Analysis
--------------------------------------------------------------

Default password is: ``admin``

http://localhost:8888/notebooks/AntiNex-Protecting-Django.ipynb

View Notebook Presentation Slides
---------------------------------

#.  Use ``Alt + r`` inside the notebook

#.  Use the non-vertical scolling url: http://localhost:8889/Slides-AntiNex-Protecting-Django.slides.html
