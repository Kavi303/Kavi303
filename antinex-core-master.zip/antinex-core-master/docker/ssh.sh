#!/bin/bash

echo ""
echo "sshing"
docker exec -it ai-core bash
