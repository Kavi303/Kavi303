#!/bin/bash

echo ""
echo "starting stack"
docker-compose -f ./full-stack.yml up -d 
